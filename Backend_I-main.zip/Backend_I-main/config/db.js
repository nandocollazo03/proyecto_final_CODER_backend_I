const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    await mongoose.connect('mongodb+srv://nandocollazo03:collaNando123@mi-aplicacion-coder-clu.rqf7i3x.mongodb.net/?retryWrites=true&w=majority&appName=mi-aplicacion-coder-cluster');
    console.log('MongoDB conectado');
  } catch (error) {
    console.error('Error al conectar a MongoDB', error);
    process.exit(1);
  }
};

module.exports = connectDB;