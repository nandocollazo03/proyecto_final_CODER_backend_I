const express = require('express');
const router = express.Router();
const Product = require('../models/Product');

// Listar todos los productos con paginación, filtros y ordenamiento
router.get('/', async (req, res) => {
    const { limit = 10, page = 1, sort, query } = req.query;

    const queryObject = {};
    if (query) {
        queryObject.$or = [
            { category: new RegExp(query, 'i') },
            { status: query === 'true' }
        ];
    }

    const sortOption = sort === 'asc' ? 'price' : (sort === 'desc' ? '-price' : '');

    try {
        const totalProducts = await Product.countDocuments(queryObject);
        const products = await Product.find(queryObject)
            .sort(sortOption)
            .limit(parseInt(limit))
            .skip((page - 1) * limit);

        const totalPages = Math.ceil(totalProducts / limit);
        const prevPage = page > 1 ? page - 1 : null;
        const nextPage = page < totalPages ? page + 1 : null;

        res.json({
            status: 'success',
            payload: products,
            totalPages,
            prevPage,
            nextPage,
            page,
            hasPrevPage: prevPage !== null,
            hasNextPage: nextPage !== null,
            prevLink: prevPage ? `/api/products?limit=${limit}&page=${prevPage}&sort=${sort}&query=${query}` : null,
            nextLink: nextPage ? `/api/products?limit=${limit}&page=${nextPage}&sort=${sort}&query=${query}` : null
        });
    } catch (err) {
        res.status(500).json({ status: 'error', message: err.message });
    }
});

module.exports = router;