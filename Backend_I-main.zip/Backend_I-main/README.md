# Backend I - Proyecto final

Este proyecto es una aplicación backend para un sitio de comercio electrónico, desarrollado con Node.js y MongoDB. El backend proporciona funcionalidades para gestionar productos y carritos de compras, así como para interactuar con una interfaz web en tiempo real usando Socket.io.

## Contenidos del Proyecto

- **`server.js`**: Archivo principal del servidor que configura Express, Mongoose, y Socket.io.
- **`models/Product.js`**: Modelo de Mongoose para los productos.
- **`models/Cart.js`**: Modelo de Mongoose para los carritos.
- **`routes/products.js`**: Rutas para la gestión de productos.
- **`routes/carts.js`**: Rutas para la gestión de carritos.
- **`routes/views.js`**: Rutas para renderizar las vistas con Handlebars.
- **`views/`**: Plantillas Handlebars para la vista de productos y carritos.
- **`data/`**: Archivos JSON para la persistencia local (se reemplazarán por MongoDB).
- **`public/`**: Archivos estáticos como CSS y JavaScript.

## Requisitos

- Node.js (v14 o superior)
- MongoDB (local o en la nube)
- npm